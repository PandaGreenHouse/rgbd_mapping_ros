#include "depth_edge.h"

void jump_edge(cv::Mat &depthMat, cv::Mat &edgeMap, int n, int jumpThresh)
{
    int height = depthMat.rows;
    int width = depthMat.cols;
    for(int y=n; y < height-n; ++y)
    {
        for(int x=n; x < width-n; ++x)
        {
            if(edgeMap.at<unsigned char>(y,x)==1)
                continue;
            bool bJump = true;
            //scanning horizontally
            for(int ix=0; ix < n; ++ix)
            {
               int diff = fabs(depthMat.at<float>(y,x-ix) - depthMat.at<float>(y,x+ix));
               if(diff < jumpThresh)
               {
                   bJump = false;
                   break;
               }
            }
            if(bJump==false)
            {
                for(int iy=0; iy < n; ++iy)
                {
                   int diff = fabs(depthMat.at<float>(y-iy,x) - depthMat.at<float>(y+iy,x));
                   if(diff < jumpThresh)
                   {
                       bJump = false;
                       break;
                   }
                }
            }
            if(bJump==true)
            {
               edgeMap.at<unsigned char>(y,x)=1;
            }
        }
    }
}
